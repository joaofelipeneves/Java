public class dataItems {
	
	private String Names;
	private int Prices;
	
	public dataItems (int Prices, String Names) {
		this.Prices = Prices;
		this.Names = Names;
	}
		public String getNames() {
		return Names;
	}
		public int getPrices() {
		return Prices;
	}

	
}